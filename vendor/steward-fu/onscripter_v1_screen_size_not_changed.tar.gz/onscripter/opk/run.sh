#!/bin/sh
mypath=$(dirname "$0")
gamedir=$(dirname "$1")

cd "$mypath";
LD_LIBRARY_PATH=. ./onscripter -r "$gamedir"
