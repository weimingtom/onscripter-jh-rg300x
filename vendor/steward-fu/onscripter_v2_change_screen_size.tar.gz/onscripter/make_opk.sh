#!/bin/sh
mksquashfs onscripter opk/* onscripter.opk -all-root -noappend -no-exports -no-xattrs -no-progress >/dev/null
